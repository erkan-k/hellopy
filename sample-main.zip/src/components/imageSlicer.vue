<template>
  <v-container>
    <v-responsive class="d-flex align-center text-center fill-height">
      <div class="text-body-2 font-weight-light mb-n1">Welcome to</div>
      <h1 class="text-h2 font-weight-bold">Image Slicer</h1>

      <v-row class="mt-10">
        <v-col cols="12" :md="splitImages.length > 0 ? 6 : 12">
          <div class="d-flex mt-10">
            <v-file-input
              label="Please Choose Image"
              accept="image/png, image/jpeg, image/jpg"
              @change="handleFileChange"
              @click="clear"
            ></v-file-input>
            <v-btn
              color="error"
              size="small"
              v-if="selectedImg"
              density="default"
              @click="clear"
              icon="mdi-close"
            ></v-btn>
          </div>

          <v-img v-if="selectedImg" :src="selectedImg"> </v-img>
          <v-divider class="ms-3" inset vertical></v-divider>
        </v-col>
        <v-col cols="12" md="6">
          <div class="mt-3" v-if="splitImages.length > 0">
            <p class="font-weight-bold text-h5">Split Images :</p>
            <v-row class="mt-2">
              <v-col
                v-for="(image, index) in splitImages"
                :key="index"
                cols="12"
                md="6"
              >
                <v-img
                  class="pointer rounded-lg elevation-3"
                  :src="image"
                  alt="Split image"
                />
              </v-col>
            </v-row>
          </div>
        </v-col>
      </v-row>
    </v-responsive>
  </v-container>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      selectedFile: null,
      selectedImg: "",
      splitImages: [],
    };
  },
  methods: {
    handleFileChange(event) {
      this.selectedFile = event.target.files[0];
      this.selectedImg = URL.createObjectURL(this.selectedFile);
      this.splitImage();
    },
    async splitImage() {
      if (!this.selectedFile) {
        console.error("Please select an image first.");
        return;
      }

      let formData = new FormData();
      formData.append("image", this.selectedFile);
      console.log(formData);
      this.splitImages = []
      try {
        const response = await axios.post(
          "http://localhost:5000/split-image/",
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );

        this.splitImages = ["../../server/sliced_0.png","../../server/sliced_1.png","../../server/sliced_2.png","../../server/sliced_3.png"]
      } catch (error) {
        console.error("Error splitting the image:", error);
      }
    },
    clear() {
      this.selectedImg = "";
      this.splitImages = [];
    },
  },
};
</script>
<style>
.pointer {
  cursor: pointer;
}
</style>
