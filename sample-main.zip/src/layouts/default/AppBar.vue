<template>
  <v-app-bar flat>
    <v-app-bar-title>
      <v-icon icon="mdi-circle-slice-4" />
      Image Slicer
    </v-app-bar-title>
  </v-app-bar>
</template>

<script setup>
  //
</script>
