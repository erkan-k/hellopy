<!-- eslint-disable vue/multi-word-component-names -->
<template>
  <HelloWorld />
</template>

<script setup>
  import HelloWorld from '@/components/imageSlicer.vue'
</script>
