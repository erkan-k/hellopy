from PIL import Image
from io import BytesIO
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_restful import Resource, Api, reqparse

import base64

app = Flask(__name__)
CORS(app)

def split_image(image):
    width, height = image.size
    middle_x = width // 2
    middle_y = height // 2

    # Split the image into 4 pieces
    top_left = image.crop((0, 0, middle_x, middle_y))
    top_right = image.crop((middle_x, 0, width, middle_y))
    bottom_left = image.crop((0, middle_y, middle_x, height))
    bottom_right = image.crop((middle_x, middle_y, width, height))

    print(top_left.size, "**************")
    
    top_left.save(f'sliced_0.png')
    top_right.save(f'sliced_1.png')
    bottom_left.save(f'sliced_2.png')
    bottom_right.save(f'sliced_3.png')
    return top_left, top_right, bottom_left, bottom_right

@app.route('/split-image/', methods=['POST'])

def handle_split_image():

    parser = reqparse.RequestParser()
    parser.add_argument('image', type=str, location='files')
    args = parser.parse_args()
    # Get the image data from the front-end request
    if 'image' in request.files:
        image_data = request.files['image'].read()


    # Decode base64 image data
    # image_bytes = base64.b64decode(image_data)

    # Open the image using Pillow
    image = Image.open(BytesIO(image_data))

    # Split the image
    pieces = split_image(image)

    # Save the pieces or do further processing as needed
    # For example, you can save them as separate files or send them back to the front-end

    # Convert pieces to base64 for sending them back to the front-end
    result = {
        'top_left': base64.b64encode(pieces[0].tobytes()).decode('utf-8'),
        'top_right': base64.b64encode(pieces[1].tobytes()).decode('utf-8'),
        'bottom_left': base64.b64encode(pieces[2].tobytes()).decode('utf-8'),
        'bottom_right': base64.b64encode(pieces[3].tobytes()).decode('utf-8'),
    }

    return result

if __name__ == '__main__':
    app.run()